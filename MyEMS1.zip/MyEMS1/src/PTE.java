/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hashirahmad
 */
public class PTE extends EmployeeInfo {
    
    public double hourlyWage;
    public double hoursPerWeek;
    public double weeksPerYear; 
    
    public PTE(int eN, String fN, String lN, int g, int wL, int dR, double hW, double hPw, double wY) {
        super(eN, fN, lN, g, wL, dR);
        hourlyWage = hW;
        hoursPerWeek=hPw;
        weeksPerYear=wY;
    }
    
    public double calcNetIncome(){
        return(hourlyWage*hoursPerWeek*weeksPerYear*(1.0-deductRate));
    }
}
