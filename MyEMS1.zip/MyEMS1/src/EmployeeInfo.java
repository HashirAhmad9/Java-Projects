
import java.io.Serializable;



public class EmployeeInfo implements Serializable{

    
    // attributes
    public int empNum;
    public String firstName;
    public String lastName;
    public int gender;
    public int workLoc;
    public int deductRate; // e.g. 0.21 for 21%
    
    
    // constructors
    public EmployeeInfo(int eN, String fN, String lN, int g, int wL, int dR) {
    	empNum = eN;
    	firstName = fN;
    	lastName = lN;
        gender = g;
        workLoc = wL;
    	deductRate = dR;
    }
    
    
    // methods
    
    public int getEmpNum() {
    	return empNum;
    }
    
    public String getFirstName() {
    	return firstName;
    }
    
    public String getLastName() {
    	return lastName;
    }
    
}
