/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hashirahmad
 */
public class FTE extends EmployeeInfo {
    
    
    //attributes
    public double yearlySalary;
    
    public FTE(int eN, String fN, String lN, int g, int wL, int dR, double yS) {
        super(eN, fN, lN, g, wL, dR);
        yearlySalary = yS;
    }
    
    public double getYearlySalary(){
        return yearlySalary;
    }
    
    public double calcNetIncome(){
        return(yearlySalary * (1.0 - deductRate));
    }
}
